import random
from datetime import datetime
import os.path

# Please gieve location_list in small character
import requests

location_list = ['coimbatore']
Platform = 'dailbascket'
new_td=datetime.now().strftime('%Y_%m_%d')

# db_host='192.168.1.131'
db_host='54.36.166.212'
db_user='root'
db_passwd='xbyte'
db_name = 'santa_daily_basket_pl'

input_table = f'input'
pdp_table=f'productdata_{new_td}_01'

import clr

clr.AddReference("G:\\Daily Scheduler\\0. Santa\\Dll\\Santa_Project_DLL.dll")

from Santa_Project_DLL import Santa_PL_DLL
dllobj = Santa_PL_DLL()

folder_path=dllobj.CreateFolder("G","dailbascket","IN",'***')
HTMLs = dllobj.HtmlFolderPath

Log = HTMLs + f'\\Log'
try:
    if not os.path.exists(Log):
        os.makedirs(Log)
except Exception as e:
     print('exception in makedir config file error: ', e)

""" ---make log file using logging module--- """

import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
logger.setLevel(logging.ERROR)
logger.setLevel(logging.WARNING)
logger.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(message)s')
file_handler = logging.FileHandler(Log + f'\\Santa_Otipy_log_{new_td}.log')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

def pl_link(url):
    with open('UserAgent.txt', 'r', encoding='utf8') as f:
        useragent = f.read()
        useragent = useragent.splitlines()
        useragent = random.choice(useragent)
    head = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'en-US,en;q=0.9',
        'Cache-Control': 'max-age=0',
        'Connection': 'keep-alive',
        'Cookie': 'connect.sid=s%3AXoZG4_eK9nNhBdkiR7asEert24k2ymiw.k%2FOnz7BXuK8X%2Bboz98oh1p%2F%2F%2FT3zMXZ3ycFqywt46uc; _ga=GA1.2.1760187704.1668681371; _gid=GA1.2.1721754969.1668681371; XSRF-TOKEN=BctcXvSO-ozCmF7n7lhT-Ntaf_FrLyiIEQYE',
        'Host': 'dailybasket.com',
        'Referer': 'https://www.google.com/',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': useragent
    }
    main_req = requests.get(url=url,headers=head)
    return  main_req