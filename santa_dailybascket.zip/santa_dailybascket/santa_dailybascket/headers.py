try:
    prod_sql = f"SELECT * FROM {input_table} where Status='Pending'"
    self.cursor.execute(prod_sql)
    rows = self.cursor.fetchall()
    if rows == ():
        print('spider is close Runing,...................')

        connection_string = f'datasource={db_host};username=root;password=xbyte;database={db_name};ssl mode=none;'
        Santa_csv_create = dllobj.ExportCSV(connection_string)
        print(Santa_csv_create, "----!!!")
    else:
        ...
except Exception as e:
    print(e)