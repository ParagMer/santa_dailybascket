import re
import time
from urllib import parse

import scrapy
from santa_dailybascket.config import *
from santa_dailybascket.pipelines import *

class SdbSpider(scrapy.Spider):
    name = 'sdb'
    def __init__(self, start='', end=''):
        self.start = start
        self.end = end
        self.cursor = SantaDailybascketPipeline.cursor
        self.con = SantaDailybascketPipeline.con

    def start_requests(self):
        try:
            selectquery = f"select id,Platform,Locations,`Material Name`,UOM from {input_table} where Status = 'Pending' AND ID BETWEEN {self.start} AND {self.end}"
            self.cursor.execute(selectquery)
            table = self.cursor.fetchall()
            for row in table:
                cat_row_id = row[0]
                Platform = row[1]
                Locations = row[2]
                Material_Name = row[3]
                Input_UOM = row[4]

                delete_duplicate_row = f"delete from {pdp_table} where Id1 = '{cat_row_id}'"
                self.cursor.execute(delete_duplicate_row)
                self.con.commit()

                searchtems = parse.quote(Material_Name)

                pl_url = f"https://dailybasket.com/products?search={searchtems}&page=1"

                filename = f'\\serach_{Locations}_{cat_row_id}_Page_1.html'
                path = HTMLs + filename
                path = path.replace("\\", "/")

                meta = {'cat_row_id': cat_row_id, 'Platform': Platform,
                        'Locations': Locations, 'Material_Name': Material_Name,
                        'path': path, 'Input_UOM': Input_UOM, 'count': 0
                        }

                if os.path.exists(path):
                    yield scrapy.Request(url=f'file:///{path}', callback=self.parse, meta={'meta': meta},dont_filter=True)
                else:
                    main_req = pl_link(url=pl_url)
                    pes = main_req.text
                    with open(path,'w',encoding='utf8') as f:
                        f.write(pes)
                    yield scrapy.Request(url=f'file:///{path}', callback=self.parse, meta={'meta': meta},dont_filter=True)

        except Exception as e:
            print(e)

    def parse(self, response,**kwargs):
        meta_dict = response.meta.get('meta')
        dllobj.IntializeVariable()

        cat_row_id = meta_dict.get('cat_row_id')
        Platform = meta_dict.get('Platform')
        Locations = meta_dict.get('Locations')
        Material_Name = meta_dict.get('Material_Name')
        Input_UOM = meta_dict.get('Input_UOM')
        count = meta_dict.get('count')
        path = meta_dict.get('path')
        product_data = response.xpath('''//div[contains(@class,"products")]//div[@class="d-none d-md-block border p-4"]''')
        for j in product_data:
                #todo product_url
                product_url = j.xpath('.//a//@href').get()
                if product_url:
                    if 'https://dailybasket.com' not in product_url:
                        product_url = 'https://dailybasket.com' + product_url
                    else:
                        product_url = product_url
                    dllobj.Product_URL = product_url

                    # todo product_code
                    try:
                        product_code = str(product_url).split('/')[-1].replace("']", '')
                        dllobj.Product_Code = str(product_code)
                    except Exception as e:
                        print('Error in product_code', e)

                    # todo price
                    try:
                        price = j.xpath('.//div[@class="mrp ml-auto mr-2"]//strong//text()').get()
                        price = price.replace('₹', '')
                        dllobj.Price = price
                    except Exception as e:
                        print('Error in price', e)

                    # todo Quantity
                    try:
                        size = j.xpath('.//div[@class="size "]/strong/text()').get()
                        if size:
                            size = size
                        else:
                            size = response.xpath('.//select[@name="qty"]//text()').getall()
                            for i in size:
                                if 'KG' in i:
                                    size = i
                        UOM = re.sub('\d+\.?', '', size)
                        # quantity = re.findall('\d', size)
                        # quantity = "".join(quantity)
                        dllobj.Quantity = size
                        dllobj.UOM = UOM.strip()
                    except Exception as e:
                        print('Error in Quantity', e)

                    # todo product_title
                    try:
                        product_title = j.xpath('.//div[@class="title mt-3 "]//text()').getall()
                        product_title = ''.join(product_title)
                        dllobj.Product_Title = product_title.strip()
                    except Exception as e:
                        print('Error in product_title', e)

                    dllobj.Htmlpath = str(path)
                    dllobj.Material_Name = str(Material_Name)
                    dllobj.Input_UOM = str(Input_UOM)
                    dllobj.Platform = str(Platform)
                    dllobj.Locations = str(Locations)
                    dllobj.Id1 = str(cat_row_id)
                    dllobj.Status = 'Done'

                    try:
                        error_msg = dllobj.QAChecks()

                        if error_msg == '':
                            Insert_Qry = dllobj.InsertQuery()
                            print(Insert_Qry)
                            self.cursor.execute(Insert_Qry)
                            self.con.commit()
                            print("!!!" * 25, "Insert Successfully...")
                        else:
                            print("Getting Error in QA Check ,", error_msg)
                            return None
                    except Exception as E:
                        print(E)
                        return None
                    count += 1
                else:
                    print('Product url is blank')
                    time.sleep(3)
                    return None
        try:
            Done_cate_qry = f'update {input_table} set Htmlpath="{path}", count="{count}", status="Done" where id = "{cat_row_id}"'
            self.cursor.execute(Done_cate_qry)
            self.con.commit()

            print(f"--------------------------------- Upadated Category Id =  {cat_row_id}")
        except Exception as E:
            print(E)
            return None
    def close(self, spider):
        try:
            prod_sql = f"SELECT * FROM {input_table} where Status='Pending'"
            self.cursor.execute(prod_sql)
            rows = self.cursor.fetchall()
            if rows == ():
                print('spider is close Runing,...................')

                connection_string = f'datasource={db_host};username=root;password=xbyte;database={db_name};ssl mode=none;'
                Santa_csv_create = dllobj.ExportCSV(connection_string)
                print(Santa_csv_create, "----!!!")
            else:
                ...
        except Exception as e:
            print(e)
if __name__ == '__main__':
    from scrapy.cmdline import execute
    execute('scrapy crawl sdb -a start=1 -a end=122'.split())