# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
import pymysql
from santa_dailybascket.config import *


class SantaDailybascketPipeline:
    try:
        con = pymysql.connect(host=db_host, user=db_user, password=db_passwd)
        db_cursor = con.cursor()
        create_db = f"create database if not exists `{db_name}` CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci"
        db_cursor.execute(create_db)
        con.close()

        con = pymysql.connect(host=db_host, user=db_user, password=db_passwd, database=db_name, autocommit=False,
                              use_unicode=True, charset="utf8")
        cursor = con.cursor()

        try:

            create_table = "create table if not exists " + input_table + """ 
                                                                          (
                                                                               `id` int(11) NOT NULL AUTO_INCREMENT,
                                                                               `Platform` varchar(50) DEFAULT NULL,
                                                                               `Locations` varchar(50) DEFAULT NULL,
                                                                               `Material Name` varchar(200) DEFAULT NULL,
                                                                               `UOM` varchar(50) DEFAULT NULL,
                                                                               `Htmlpath` varchar(500) DEFAULT NULL,
                                                                               `count` varchar(100) DEFAULT NULL,
                                                                               `Status` varchar(10) DEFAULT 'Pending',
                                                                               `Status` varchar(10) DEFAULT 'Pending',
                                                                               PRIMARY KEY (`id`)
                                                                          )                                                                                         
                   """
            cursor.execute(create_table)

            # TODO Create Input Table
            try:
                input_data_qry = f'SELECT * From {input_table}'
                cursor.execute(input_data_qry)
                all_data = cursor.fetchall()
                if all_data == () and len(all_data) < 50:
                    for i in location_list:
                        insert_qry_for_input = f"INSERT INTO input (`Material Name`,`UOM`,`Locations`,`Platform`) SELECT `Material Name`,`UOM`,'{str(i).title()}','{Platform}' FROM {i}_location"
                        cursor.execute(insert_qry_for_input)
                        con.commit()

                    print(
                        "!!!!!!!!!!!!!!!!!!!!!!!    Input Table Create Successfully !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
                else:
                    print("!!!!!!!!!!!!!!!!!!!!!!!    Input Table Already Exist !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")

            except Exception as E:
                print(E)

            # TODO Pending Input Table
            try:
                Exist_or_not_qry = f'SELECT * FROM information_schema.tables WHERE table_schema = "{db_name}" AND table_name = "{pdp_table}"'
                cursor.execute(Exist_or_not_qry)
                all_data_pdp = cursor.fetchall()
                if all_data_pdp == ():
                    pending_input = f'update {input_table} set status = "Pending"'
                    cursor.execute(pending_input)
                    con.commit()
                    print(
                        "!!!!!!!!!!!!!!!!!!!!!!!    Update Input Table status Pending  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
                else:
                    print(
                        f"!!!!!!!!!!!!!!!!!!!!!!!    {pdp_table} Table Already Exist !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
            except Exception as E:
                print(E)

            create = dllobj.CreateTable()
            print(create)
            try:
                query = [i for i in create.split(';') if i]
                for i in query:
                    cursor.execute(i)
                    con.commit()
            except Exception as e:
                print('Dll table making issue.:', e)


        except Exception as e:
            print(e)
    except Exception as e:
        print(e)

